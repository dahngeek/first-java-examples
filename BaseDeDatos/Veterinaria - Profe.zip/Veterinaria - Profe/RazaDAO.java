
/**
 * Write a description of class RazaDAO here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.sql.*;
import java.util.*;

public class RazaDAO extends Conexion
{
    public void nuevaRaza(String raza) throws SQLException
    {
        String sql = "INSERT INTO raza (raza) VALUES (?)";
        conectar();
        PreparedStatement ps = conexion.prepareStatement(sql);
        ps.setString(1, raza);
        ps.execute();
        ps.close();
        desconectar();
    }
    
    public void modificarRaza(int id, String nuevaRaza) throws SQLException
    {
        String sql = "UPDATE raza SET raza=? WHERE id=?";
        
        conectar();
        PreparedStatement ps = conexion.prepareStatement(sql);
        ps.setString(1, nuevaRaza);
        ps.setInt(2, id);
        ps.execute();
        ps.close();
        desconectar();
    }
    
    public void eliminarRaza(int id) throws SQLException
    {
        String sql = "DELETE FROM raza WHERE id=?";
        conectar();
        PreparedStatement ps = conexion.prepareStatement(sql);
        ps.setInt(1, id);
        ps.execute();
        ps.close();
        desconectar();
    }
    
    public List listarRaza() throws SQLException
    {
        List lista = new ArrayList();
        
        String sql = "SELECT * FROM raza";
    
        conectar();
        Statement st = conexion.createStatement();
        ResultSet rs = st.executeQuery(sql);
        
        while(rs.next())
        {
            Raza r = new Raza();
            r.setId(rs.getInt("id"));
            r.setRaza(rs.getString("raza"));
            lista.add(r);
        }
       
        return lista;
    }
}
