
/**
 * Write a description of class Raza here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Raza
{
    int id;
    String raza;
    
    public Raza()
    {
    }
    
    public void setId(int id)
    {
        this.id=id;
    }
    
    public int getId()
    {
        return id;
    }
    
    public void setRaza(String raza)
    {
        this.raza=raza;
    }
    
    public String getRaza()
    {
        return raza;
    }
    
}
