
/**
 * Write a description of class Principal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.sql.*;
import java.util.*;

public class Principal 
{
    RazaDAO rdao = new RazaDAO();
    
    public void menu() throws SQLException
    {
        int op=0;
        do
        {
            System.out.println("1. Nueva raza");
            System.out.println("2. Modificar raza");
            System.out.println("3. Eliminar raza");
            System.out.println("4. Listar razas");
            op=Console.readInt("Seleccione una opción");
            
            switch(op)
            {
                case 1: 
                    nuevaRaza();
                    break;
                case 2: 
                    modificarRaza();
                    break;
                case 3: 
                    eliminarRaza();
                    break;
                case 4: 
                    listarRazas();
                    break;
                case 0:
                    System.out.println("Gracias por usar el sistema");
                    break;
            }
        }while(op!=0);
    }
    
    public void nuevaRaza() throws SQLException
    {
        String nombre = Console.readLine("Ingrese la raza a guardar: ");
        
        rdao.nuevaRaza(nombre);
    }
    
    public void modificarRaza()throws SQLException
    {
        listarRazas();
        
        int op = Console.readInt("Elija la raza a modificar");
        
        String raza = Console.readLine("Nueva raza: ");
        
        rdao.modificarRaza(op, raza);
    }
    
    public void eliminarRaza()throws SQLException
    {
        listarRazas();
        
        int op = Console.readInt("Elija la raza a eliminar");
        
        rdao.eliminarRaza(op);
        
    }
    
    public void listarRazas() throws SQLException
    {
        List lista = rdao.listarRaza();
        
        Iterator it = lista.iterator();
        
        while(it.hasNext())
        {
            Raza r = (Raza) it.next();
            System.out.println(r.getId() + ". " + r.getRaza());
        }
    }
    
}
